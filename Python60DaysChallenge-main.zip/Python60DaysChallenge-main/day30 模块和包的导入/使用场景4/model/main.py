# main.py
from utils import circle # 这是根目录绝对路径的导入方式

radius = 5
area = circle.calculate_area(radius)
print(f"半径为 {radius} 的圆，面积是: {area}")




