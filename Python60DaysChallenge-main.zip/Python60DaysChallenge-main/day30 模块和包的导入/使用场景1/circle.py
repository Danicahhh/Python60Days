# circle.py
import math

def calculate_area(radius):
    return math.pi * radius ** 2